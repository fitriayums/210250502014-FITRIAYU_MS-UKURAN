/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PROGRAM_1_KONDISI;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class SATU_KONDISI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int Ukuran;
        System.out.print("Masukkan Berapa Ukuran Sepatu (EROPA) : ");
        Ukuran = input.nextInt();

        if (Ukuran < 35) {
            System.out.println("Ukuran Sepatu Anak anak ");
        } else {
            System.out.println("Ukuran Sepatu Orang Dewasa");
        }
    }
}
