  /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PROGRAM_2_KONDISI;

import java.util.Scanner;

/**
 *
 * @author ASUS
 */
public class DUA_KONDISI {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int Ukuran;
        System.out.print("Masukkan Berapa cm ukuran foot length : ");
        Ukuran = input.nextInt();

        if (Ukuran >= 8 && Ukuran <= 12) {
            System.out.println("Ukuran Sepatu Balita");
        } else if (Ukuran >= 13 && Ukuran <= 24) {
            System.out.println("Ukuran Sepatu Anak-anak 6-10 Tahun");
        } else {
            System.out.println("Ukuran Sepatu Orang Dewasa");
        }
    }
}
